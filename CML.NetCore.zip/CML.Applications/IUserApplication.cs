﻿namespace CML.Applications
{
    public interface IUserApplication
    {
        bool Login(string userName, string pwd);
    }
}
